package com.example.aplicativobancario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnExtrato = findViewById(R.id.btnExtrato);
        Button btnDebito = findViewById(R.id.btnDebito);

        btnExtrato.setOnClickListener(v ->{
            Intent intent = new Intent(this,extrato.class);
            startActivity(intent);
        });

        btnDebito.setOnClickListener(v ->{
            Intent intent = new Intent(this,debito.class);
            startActivity(intent);
        });

        Button btnCartao = findViewById(R.id.btnCartao);

        btnCartao.setOnClickListener(v ->{
            Intent intent = new Intent(this,cartao.class);
            startActivity(intent);
        });
    }
}